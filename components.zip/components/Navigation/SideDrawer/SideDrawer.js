import React from 'react';
import Logo from '../../Logo/Logo';
import NavigationItems from '../NavigationItems/NavigationItems';
import CSSModules from 'react-css-modules';
import styles from './SideDrawer.module.css';
import Backdrop from '../../UI/Backdrop/Backdrop';
import Aux from '../../../hoc/Aux'
 
const sideDrawer = (props) => {
	return (
		<Aux>
			<Backdrop show={props.showSide} click={props.backDropClick}/>
		<div styleName={`SideDrawer ${ props.showSide ? 'Open': 'Close'}`}>
			<div styleName='Logo'>
				<Logo/>
			</div>
			<nav>
				<NavigationItems />
			</nav>
		</div>
		</Aux>
	);
}

export default CSSModules(sideDrawer,styles, {allowMultiple: true});