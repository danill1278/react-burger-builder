import React from 'react';
import styles from './DrawerToggle.module.css';
import CSSModules from 'react-css-modules';

const drawerToggle = (props) => {
	return (
	<div onClick={props.clicked} styleName='DrawerToggle'>
		<div></div>
		<div></div>
		<div></div>
	</div>
	)
}

export default CSSModules(drawerToggle,styles);