import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './Toolbar.module.css';
import Navigation from '../NavigationItems/NavigationItems';
import Logo from '../../Logo/Logo';
import DrawerToggle from '../SideDrawer/DrawerToggle/DrawerToggle';
 
const toolbar = (props) => {
	return (
	<header styleName="Toolbar">
		<div styleName='MobileOnly'>
			<DrawerToggle  clicked={props.menuBtnClick}>Menu</DrawerToggle>
		</div>
		<div styleName="Logo">
			<Logo/>
		</div>
		<nav styleName='DesctopOnly'>
			<Navigation></Navigation>
		</nav>
	</header>
	)
};



export default CSSModules(toolbar,styles);