import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './navigationItem.module.css';
 
const navigationItem = (props) => {
	return  <li styleName={`NavigationItem`}><a href={props.link} styleName={`${props.active? 'active': ''}`}>{props.children}</a></li>	
}

export default CSSModules(navigationItem,styles, {allowMultiple: true});