import React, {Component} from 'react';
import Aux from '../../hoc/Aux';
import CSSModules from 'react-css-modules';
import styles from './Layout.module.css';
import  Toolbar from '../Navigation/Toolbar/Toolbar';
import SideDrawer from '../Navigation/SideDrawer/SideDrawer';


class Layout extends Component {
	constructor(props) {
		super(props);
		console.log('constractor');
	}
	state= {
		showSideDrower: false
	}
	closeSideDrawer = () => {
		// this.setState((prevState) => {
		// 	return {showSideDrower: !prevState.showSideDrower}
		// })
		this.setState(
			{showSideDrower: false }
	    )
	}
	
	openSideDrawer = () => {
		this.setState((prevState) => {
				return {showSideDrower: !prevState.showSideDrower }
		})
		
	}
	render() {
		return (
			<div>
				<Aux>
					<Toolbar menuBtnClick={this.openSideDrawer}/>
					<SideDrawer showSide={this.state.showSideDrower} backDropClick={this.closeSideDrawer} />
					<main styleName='Content'>
						{this.props.children}
					</main>
				</Aux>
			</div>
		)
	}
	
}

export default CSSModules(Layout,styles);
