import React from 'react';
import styles from './Backdrops.module.css';
import CSSModules from 'react-css-modules';

const backdrop = (props) => {
	return	 props.show ? <div styleName='Backdrop' onClick={props.click}></div> : null;
}

export default CSSModules(backdrop, styles);