import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './Button.module.css';

const button = (props) => {
	return (
		<button styleName={`Button ${props.type}`} onClick={props.clicked}> {props.children} </button>
	)
}

export default CSSModules(button,styles,{allowMultiple: true});