import React from 'react';
import Aux from '../../../hoc/Aux';
import Button from '../../UI/Button/Button';

const orderSummary = (props) => {
	const ingridientsSummary = Object.keys(props.ingredients).map( (key,i) => {
		if (props.ingredients[key] > 0 ) {
			return <li key={i}>{key}: {props.ingredients[key]}</li>
		}  else {
			return null;
		}
	})

	return (
		<Aux>
			<h3>Yoir Order</h3>
			<p>Adelicious</p>
			<ul>
				{ingridientsSummary}
			</ul>
			<p>Continue To Checkout</p>
			<strong>Total price: {props.totalPrice.toFixed(2)}</strong>
			<br/>
			<Button type='Danger' clicked={props.clickOnCancel}>CANCEL</Button>
			<Button type='Success' clicked={props.clickOnContinue}>CONTINUE</Button>
		</Aux>
	)
}

export default orderSummary;