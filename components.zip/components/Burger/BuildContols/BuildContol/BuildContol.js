import React from 'react';
import styles from './BuildContol.module.css';
import CSSModules from 'react-css-modules';


const buildControls = (props) => {
	return (
	<div styleName='BuildControl'>
			<div styleName='Label'>{props.label}</div>
			<button styleName={`Less ${props.status}`} onClick={props.removed}>Less</button>
			<button styleName='More'  onClick={props.added}>More</button>
	</div>
	
	)
}

export default CSSModules(buildControls, styles, {allowMultiple: true});