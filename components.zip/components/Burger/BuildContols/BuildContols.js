import React from 'react';
import styles from './BuildContols.module.css';
import CSSModules from 'react-css-modules';
import BuildControl from './BuildContol/BuildContol';

const controls = [
	{ label: 'Salad', type: 'salad'},
	{ label: 'Bacon', type: 'bacon'},
	{ label: 'Cheese', type: 'cheese'},
	{ label: 'Meat', type: 'meat'}
];

const buildControls = (props) => {
	
	return (
	<div styleName='buildControls'>
		{props.priceCount.toFixed(2)}
		{ controls.map((ctrl,i) => {
			return <BuildControl  
			label={ctrl.label} 
			type={ctrl.type} 
			key={i}
			status={props.ingredintsCount[ctrl.type] === 0 ? 'inactive' : 'active'}
			added = {() => props.ingredientAdded(ctrl.type)}
			removed = { () => props.ingredientRemover(ctrl.type)}
			/>
		 }) 
		}
		<button styleName='OrderButton' onClick={props.purchase}  disabled={props.purchased}>Order Now</button>
	</div>
	);
}

export default CSSModules(buildControls, styles);