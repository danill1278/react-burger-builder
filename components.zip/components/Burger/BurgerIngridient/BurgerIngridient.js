import React, {Component} from 'react';
import CSSModules from 'react-css-modules';
import styles from './BurgerIngredient.module.css';
import PropTypes from 'prop-types';


class BurgerIngridient extends Component {
	
	render() {
		let ingredient = null;
		switch ( this.props.type ) {
			case ('bread-bottom') : 
				ingredient = <div styleName='BreadBottom'></div>;
				break;
			case ('bread-top') : 
				ingredient = (
					<div styleName='BreadTop'>
						<div styleName='Seeds1'></div>
						<div styleName='Seeds2'></div>
					</div>
				);
				break;
			case ('meat') : 
				ingredient = <div styleName='Meat'></div>;
				break;
			case ('cheese') : 
				ingredient = <div styleName='Cheese'></div>
				break;
			case ('salad') : 
				ingredient = <div styleName='Salad'></div>
				break;
			case ('bacon') : 
				ingredient = <div styleName='Bacon'></div>
				break;
			default: 
				ingredient = null;
		}
	
		return ingredient;
	}
	
};

BurgerIngridient.propTypes = {
	type: PropTypes.string.isRequired,
	
}


export default CSSModules(BurgerIngridient, styles);