import React,{Component} from 'react';
import Aux from '../../hoc/Aux';
import Burger from '../../components/Burger/Burger';
import BurgerControls from '../../components/Burger/BuildContols/BuildContols';
import Modal from '../../components/UI/Modal/Modal';
import OrderSummary from '../../components/Burger/OrderSummary/OrderSummary';

const INGREDIENT_PRICES = {
	salad: 0.5,
	cheese: 0.4,
	meat: 1.3, 
	bacon:0.7
}
class BurgerBuilder extends Component {
	constructor(props) {
		super(props);
		this.state = {
			ingredients: {
				salad: 0,
				bacon: 0,
				cheese: 0,
				meat: 0
			},
			totalPrice: 4,
			purchase: true,
			showOrderModal: false
		};
	}

	updatePurchaseState = (updatedIngredients) => {
		const ingredients = {
			...updatedIngredients
		}
		
		const sum = Object.keys(ingredients)
			 .map( (key) => {
				return ingredients[key];
			 })
			 .reduce((acc, item) => {
				 return acc + item;
			 },0);
			
		if (sum > 0) {
			this.setState({purchase: false});
		} else {
			this.setState({purchase: true});
		}
	}

	addIngredientHamdler = (type) => {
		const oldCount = this.state.ingredients[type];
		const updatedCounte = oldCount + 1;
		const updatedIngredients = {
			...this.state.ingredients
		}
		updatedIngredients[type] = updatedCounte;
		const priceAddition = INGREDIENT_PRICES[type];
		const oldPrice = this.state.totalPrice;
		const newPrice = oldPrice + priceAddition;

		this.setState({ ingredients: updatedIngredients,totalPrice: newPrice})
		this.updatePurchaseState(updatedIngredients);
	}
	removeIngredientHamdler = (type) => {
		const oldCount = this.state.ingredients[type];
		const newValue = oldCount - 1 < 0 ? 0 : oldCount - 1 ;
		const updatedIngredients = {
			...this.state.ingredients
		}
		updatedIngredients[type] = newValue;
		const priceAddition = INGREDIENT_PRICES[type];
		const oldPrice = this.state.totalPrice;
		const newPrice = oldPrice - priceAddition < 0 ? 0 : oldPrice - priceAddition;
		

		this.setState({
			ingredients: updatedIngredients,
			totalPrice: newPrice
		})
		this.updatePurchaseState(updatedIngredients);
	}
	purchasing = () =>{
		console.log(this.state.showOrderModal, this.state.purchase);
		if (!this.state.purchase)  {
			this.setState({showOrderModal: true})
		}
	}
	closeModal = () => {
		console.log('close');
		this.setState({showOrderModal: false})
	}
	contionuePurchase = () => {
		alert('Continue');
		this.setState({showOrderModal: false})
	}
	render() {
		return (
			<Aux>
				<Burger ingredients={this.state.ingredients} />
				
				<BurgerControls priceCount={this.state.totalPrice} ingredientAdded={this.addIngredientHamdler} ingredintsCount={this.state.ingredients} ingredientRemover={this.removeIngredientHamdler} purchase={this.purchasing}  purchased={this.state.purchase}/>

				<Modal showModal={this.state.showOrderModal} closeModal={this.closeModal}>
					<OrderSummary ingredients={this.state.ingredients} clickOnCancel={this.closeModal} clickOnContinue={this.contionuePurchase} totalPrice={this.state.totalPrice}/>
				</Modal>
			</Aux>
		)
	}
}

export default BurgerBuilder;