import React from 'react';
import burgerLogo from '../../assets/images/burger-logo.png';
import CSSModules from 'react-css-modules';
import styles from './Logo.module.css';


const logo = () => {
	return (
		<div styleName='Logo'>
			<img src={burgerLogo}  alt='burger-logo'/>
		</div>
	) 
}

export default CSSModules(logo,styles);

