import React from 'react';
import styles from './Modal.module.css';
import CSSModules from 'react-css-modules';
import Backdrop from '../Backdrop/Backdrop';
import Aux from '../../../hoc/Aux';

const modal =  (props) => {
	return (
		<Aux>
			<div styleName='Modal'
			style={{
				opacity: props.showModal ? '1' : '0',
				visibility: props.showModal ? 'visible' : 'hidden'
			}}
			>
				{props.children}
			</div>
			<Backdrop  show={props.showModal} click={props.closeModal}/>
		</Aux>
	)
	
}	

export default CSSModules(modal, styles);