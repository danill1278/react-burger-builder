import React from 'react';
import Logo from '../../Logo/Logo';
import NavigationItems from '../NavigationItems/NavigationItems';
import CSSModules from 'react-css-modules';
import styles from './SideDrawer.module.css';
 
const sideDrawer = (props) => {

	return (
		<div>
			<Logo />
			<nav>
				<NavigationItems />
			</nav>
		</div>
	);
}

export default CSSModules(sideDrawer,styles);