import React from 'react';
import NavigationItem from './NavigationItem/NavigationItem';
import CSSModules from 'react-css-modules';
import styles from './navigationItems.module.css';
 
const navigationItems = () => {
	return (
		<ul styleName='NavigationItems'>
			<NavigationItem link="/" active="true" >Burger Builder</NavigationItem>
			<NavigationItem link="/" >Checkout</NavigationItem>
		</ul>
	)
	
}

export default CSSModules(navigationItems,styles);