import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './Toolbar.module.css';
import Navigation from '../NavigationItems/NavigationItems';
import Logo from '../../Logo/Logo'
 
const toolbar = (props) => {
	return (
	<header styleName="Toolbar">
		<div>Menu</div>
		<Logo/>
		<Navigation></Navigation>
	</header>
	)
};



export default CSSModules(toolbar,styles);