import React from 'react';
import Aux from '../../hoc/Aux';
import CSSModules from 'react-css-modules';
import styles from './Layout.module.css';
import  Toolbar from '../Navigation/Toolbar/Toolbar';


const Layout = (props) => {
	return (
		
		<div>
			<Aux>
				<Toolbar/>
				<main styleName='Content'>
					{props.children}
				</main>
			</Aux>
		</div>
	)
}

export default CSSModules(Layout,styles);
