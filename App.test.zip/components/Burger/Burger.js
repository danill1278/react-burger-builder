import React from 'react';
import CSSModules from 'react-css-modules';
import styles from './Burger.module.css';
import BurgerIngridient from './BurgerIngridient/BurgerIngridient';

const burger = (props) => {
	let trasformIngredients = Object.keys(props.ingredients)
	.map( igKey => {
		return [...Array(props.ingredients[igKey])].map((_, i) => {
			return <BurgerIngridient key={igKey + i} type={igKey} />
		});
	})
	.reduce( (arr, el) => {
		return arr.concat(el);
	}, [])


	if ( trasformIngredients.length === 0) {
		trasformIngredients = <p>Please adding ingredients!</p>
	}
	return (
		<div styleName='Burger'>
			<BurgerIngridient type="bread-top" />
			{trasformIngredients}
			<BurgerIngridient type="bread-bottom" />
		</div>
	);
};

export default CSSModules(burger, styles);